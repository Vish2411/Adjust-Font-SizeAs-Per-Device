//
//  Utils.swift
//  RadioCity
//
//  Created by iMac on 26/08/22.
//

import Foundation
import UIKit

enum FontName: String {
    case regular                                   = "Montserrat-Regular"
    case semiBold                                  = "Montserrat-SemiBold"
    case Bold                                      = "Montserrat-Bold"
    case Medium                                    = "Montserrat-Medium"
}

enum FontSize: CGFloat {
    case size_8                                     = 8.0
    case size_9                                     = 9.0
    case size_10                                    = 10.0
    case size_11                                    = 11.0
    case size_12                                    = 12.0
    case size_13                                    = 13.0
    case size_14                                    = 14.0
    case size_15                                    = 15.0
    case size_16                                    = 16.0
    case size_17                                    = 17.0
    case size_18                                    = 18.0
    case size_20                                    = 20.0
    case size_22                                    = 22.0
    case size_24                                    = 24.0
    case size_25                                    = 25.0
    case size_28                                    = 28.0
    case size_32                                    = 32.0
    case size_33                                    = 33.0
    case size_34                                    = 34.0
    case size_30                                    = 30.0
    case size_35                                    = 35.0
    case size_36                                    = 36.0
    case size_50                                    = 50.0
}

class Utils: NSObject {
    
    static func setFontSizeAsPerDeviceHeight(currentSize : FontSize) -> CGFloat {
        let size = currentSize.rawValue * UIScreen.main.bounds.height / 812
        return size
        
    }
    
    static func getFont(name: FontName, size: FontSize) -> UIFont {
        return UIFont(name: name.rawValue, size: Utils.setFontSizeAsPerDeviceHeight(currentSize: size)) ?? .systemFont(ofSize: 15.0)
    }
}

